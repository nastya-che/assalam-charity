var gulp = require('gulp'),
    concatCss = require('gulp-concat-css'),
    rename = require('gulp-rename'),
    notify = require('gulp-notify'),
    // prefix = require('gulp-autoprefixer'),
    livereload = require('gulp-livereload'),
    connect = require('gulp-connect'),
    sass = require('gulp-sass'),
    minifyCss = require('gulp-minify-css');

gulp.task('connect', function () {
    connect.server({
        root:'app',
        livereload: true
    });
});

gulp.task('css', function(){
    gulp.src('css/*.css')
        // .pipe(sass())
        // .pipe(prefix('last two versions', '> 1%', 'ie9'))
        .pipe(concatCss('bundle.css'))
        .pipe(minifyCss())
        .pipe(rename('bundle.min.css'))
        .pipe(gulp.dest('app/'))
        .pipe(connect.reload());
});

gulp.task('html', function () {
    gulp.src('app/index.html')
        .pipe(connect.reload());
});

gulp.task('watch', function(){
    gulp.watch('css/*.css', ['css'])
    gulp.watch('app/index.html', ['html'])
});

gulp.task('default', ['connect', 'html', 'css', 'watch']);