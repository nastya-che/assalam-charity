'use strict';

(function(){
	// var app = angular.module('app', ["ngRoute"]);
	// var app = angular.module('app', ["ngRoute", "pascalprecht.translate"]);
	var app = angular.module('app', ['ngRoute', 'pascalprecht.translate', 'angularUtils.directives.dirPagination']);	

	app.config(['$translateProvider', '$routeProvider', function($translateProvider, $routeProvider){
		$routeProvider
			.when('/', {
				templateUrl: 'views/home.html'
			})
			.when('/about', {
				templateUrl: 'views/about.html'
			})
			.when('/news', {
				templateUrl: 'views/news.html'
			})
			.when('/gallery', {
				templateUrl: 'views/gallery.html'
			})
			.when('/video', {
				templateUrl: 'views/video.html'
			})
			.when('/contact', {
				templateUrl: 'views/contact.html'
			})
			.when('/donation', {
				templateUrl: 'views/donation.html'
			})
			.when('/album_1', {
				templateUrl: 'views/gallery/album_1.html'
			})
			.when('/album_2', {
				templateUrl: 'views/gallery/album_2.html'
			})
			.when('/album_3', {
				templateUrl: 'views/gallery/album_3.html'
			})
			.otherwise({
				redirectTo:"/"
			});


			$translateProvider.fallbackLanguage('en');
			$translateProvider.registerAvailableLanguageKeys(['en', 'rus'], {
				'en_*':'en',
				'rus_*':'rus',
				'ar_*':'ar'
			});

			$translateProvider.translations('en', {			
				menu_title:'Menu',
				menu_home:'Home',
				menu_about:'About us',
				menu_news:'News',
				menu_gallery:'Gallery',
				menu_video:'Video',
				menu_contact:'Contact us',
				menu_donation:'Make a donation',
				director:'Director of the fund',
				director_name:'DOCTOR  ELEYAN MAZEN',
				latest_news:'Latest news',
				donate_img:'<img src="img/donate_en.jpg">',
				logo_img:'<img src="img/name.png">',
				home_text:"'On the day you need to look how at little life' - claimed a famous writer. The idea of ​​creating the Foundation 'Assalam' originated with the desire to make the days of our society look like a little life, but life with a capital letter. Charitable Foundation 'Assalam' - is a non-profit charitable organization that was established in Odessa in August 2011. The Foundation's mission - to do good and to encourage others to do so is not indifferent people, to develop highly moral society that is founded on the principles of spirituality and morality, through the promotion of charity and social partnership. People who come to us came from different corners of our vast planet, but joined their city has become home - Odessa. We sincerely rejoice in helping the children, because we have the opportunity to make the world a little kinder. If you are doing business that saves someone's life or destiny, or simply making people's lives better, we are ready to assist you. We believe that good deeds and actions needed all and at all times!",
				about_text:"The main aim of the Foundation 'Assalam' is the realization of charitable activities in the public interest and certain categories of persons, giving them the necessary moral, material, financial, legal and other assistance. To achieve these goals the Foundation has the following objectives: 1) to promote the development of mass physical culture, sport and tourism, promotion of healthy lifestyle; 2) facilitating the establishment of camps recreation and health of the poor, children and youth; 3) organizing and conducting fundraisers, proceeds from which will be directed to maintenance of orphanages and other institutions for orphans and children deprived of parental care; 4) provide assistance to talented creative young people, scholarships, financial aid; 5) participation in the provision of medical care and social care implementation for sick, disabled, lonely, elderly people and others who because of their own, financial or other features in need of social support and care; 6) to contribute to the protection of motherhood and childhood; 7) participation in the organization of parties, the creation of various circles, which could contribute to the development of the capacities of children and youth; 8) to promote the development of science and education, implementation of scientific and educational programs; 9) participation in conferences, seminars, meetings, competitions for the exchange of experience and other issues that are of interest to the Fund; 10) the accumulation of financial assets and property of their subsequent use in charitable activities.",
				contact_text:"<\span> <\strong>Adress: Ukraine, Odessa, street. kanatna 83, Odessa, Odessa Oblast - Ilyichevsk Street. Danchenko 7.<\/strong> <\/span> <\span> <\strong>Phones:<\/strong> <\/span> <\span> (+38) 095 902 64 01<\p> (+38) 063 15 32 653 <\/span>  <\span>	 <\strong>E-mail:<\/strong><\p> <\a href='mailto: assalam.fund.charity@gmail.com'>assalam.fund.charity@gmail.com<\/a><\p> www.assalam-charity.com<\/span><\span><\strong>Details for the non-cash money transfer on account:<\/strong><\p> Bank: ''PrivatBank''<\p> MFI's bank: 328704<\p> ЕДРПОУ: 2643325277<\p> Recipient CHARITY FUND ''ASSALAM''<\p> Beneficiary Account: 26002054322183 <\/span>",
				enter_sum:'Enter sum:',	
				currency:"currency",
				pay: "pay",				
				donation_make: "Make a donation",
				album_1:'День радио, телевидения и связи.',
				album_2:'День толерантности.',
				album_3:'Митинг против расизма и фашизма в Украине',
				back_gallery:"Back to gallery",
				new_1: 
					{
						title: "Meeting with the Chief State HMS of Ukraine in Odessa region",
						date:"13 March 2013",
						text: '25 January 2013 was held a meeting of the Council of the representatives of public organizations and nationally- cultural communities with the Chief State HMS of Ukraine in Odessa region Tkachyk S. V. and Chief State in cases of refugees and foreigners Tkachyk O. V. We discussed the perspectives of further companionship, exactly the questions of the support of the programs of the fund “Compassion” in the work with the children of refugees, problematic questions with registration of refugees and seeking for a household. Committee on Protection of Rights and Freedoms of citizens “Shield” and the Charity Fund “Assalam” represented the President Daher Saleh Mohammad and he told about the activities of the organization.',

					},
				new_2:
					{
						title: "New Year celebration in temporary accomodation of refugees",
						date:"24 January 2013",
						text: "The tradition of celebration of New Year taking it's roots from old centuries. Most of all this holiday are waiting children, but this is not surprising, because if you make a wish on New Year's night, then it will come true. To all the kids who were doing well throughout the year comes Santa Claus with gifts. So the representatives of Public organization Committee on the protection of rights and freedoms of citizens 'The Shield' and Charity Fund 'Assalam' headed by the President Daher Saleh Muhammad decided not to depart from tradition and on 26 December, 2012 came with gifts for New Year celebration at the temporary accommodation of refugees because there live with their families 30 kids of all ages. The concert program organized and conducted by young talents of a school of creativity in Illichivsk. In gratitude for the concert and sweets young inhabitants performed with a dances in traditional costumes. With the help of the Committee and the Foundation for Children was organized sweet table, where after the event you can eat all sorts of goodies.",

					},
				new_3:
					{
						title: "New Year celebration at the Center for Children's Youth Creativity 'Promin'",
						date:"24 January 2013",
						text: "December 25, 2012 at the Center for Children's Youth Creativity 'Promin' New Year party was held. Pupils together with their teachers organized a concert for the guests and parents. Also at the festival was attended by kids who attend school in the early development of the Charity Fund 'Assalam'. They enjoyed watching the scene, because the scene had a lot fairy tale characters, and Santa Claus with his Snegoruchkoy and Baba Yaga with frights and other equally well-known characters. The representatives of Committee on protection of rights and freedoms of citizens 'Shield' and Fund 'Assalam' made a huge help in organization of the event, what they did exactly they gave sweet presents for children.",

					},
				new_4:
					{
						title: "Let's help Palestinian people together",
						date:"24 January 2013",
						text: "Public organization 'Committee on protection of rights and freedoms of citizens 'Shield' ' and Charity Fund 'Assalam' in a head of President Daher Saleh and everyone not indifferent on December 18, 2012 organized an action in Odessa. The aim of the action was dedicated to the protection of Palestinian people who live on the territory of Syria. December 16, 2012 released by the Syrian air force camp 'Yarmuk' at least two missiles, one of which hit the mosque, which was then sheltering Palestinian refugees. Number of fatal air strike on camp, where about 100,000 Palestinian refugees, was at least 25 people, not to mention the wounded. More and more Palestinian victims are seeking for help. Are destroyed not only homes, but also social facilities - hospitals, schools, bakeries. There are constant attacks on industrial buildings and power plants. Authorities are struggling to cope with basic health interventions. Begins hunger. Shortages of fuel in winter, lead to the fact that people are freezing banal in unheated areas, can not cook a hot meal. Committee on protection of rights and freedoms of citizens 'Shield' and Charity Fund 'Assalam' prepared and sent letters to The International Committee of the Red Cross and the Office of the High Commissioner for Refugees, the United Nations (UNHCR) to finally turn their attention to Palestinian people, who are innocently suffering in ",

					},
				new_5:
					{
						title: "Visit with the Commission in Chernomorskaya penal colony № 74",
						date:"13 December 2012",
						text: "October 25, 2012 the president of public organization the Committee on protection of rights and freedoms of citizens 'Shield' and the Charity Fund 'Assalam' together with the International Committee for the Protection of Human Rights in the person of the chairman George Shibanov in the commission visited the Chernomorskaya women's penal colony № 74. For objectivity the commission was attended by representatives of various government and public organizations. The main reason for the visit was the information that allegedly contain women in inhuman conditions, bullied, and young mothers, as a disciplinary measure, do not let their children who are in the children's home in the colony. The first place visited by the commission was the House of the child in the colony. At this point in it dwells 79 children under the age of 3 years. Of course the first thing that catches your eye is perfect cleanliness and order that prevailed in all areas, whether residential or chores. Was able to talk to service personnel of House of the child, learn more about the life of children. Women prisoners are allowed to see their children twice a day for two hours. Rest of the time they are engaged with educators, psychologists and nurses. If possible, with the help of patrons to lead children on trips, to the circus and a dolphinarium. And on every holiday matinees are organized, of course, with gifts and competitions. Commission has been with the visit at a time when mothers were walking with their children. Kids gladly posed for pictures and television cameras. Without any embarrassment went to the hands of the guests. From the words of mothers, it became clear that they are quiet while their children are here for them, and that with them nothing bad will happen. After the Commission followed to the library of the colony. Librarian Marina says they read almost everything, and many organizations transfer their newspapers and books. There is an exhibition of the work of prisoners, it should be noted that most of them are commendable. Have not ignored and directly those premises where women are sleeping and spending their time during off hours. Surprised the white sheets and perfect made beds. Also, members of the commission visited hospital of the colony. All the questions that interested the Commission answered responsible chief of Chernomorskaya penal colony № 74 Karakaj Olga Nikolaevna. Assured that if they want such a test could be repeated on any day at any time of the day to finally was settled strange and accusing rumors about inhuman treatment of women prisoners.",

					},
				new_6:
					{
						title: "Universal children's day",
						date:"13 December 2012",
						text: "In 1954, the General Assembly recommended that all countries to put into practice the celebration of Universal Children's Day as a day of world brotherhood and understanding of children on the activities aimed at the welfare of children around the world. UN invited governments to celebrate this day on any day that each of them is justified. November 20 marks the day on which the Assembly adopted in 1959 the Declaration on the Rights of the Child, and in 1989 - the Convention on the Rights of the Child. In temporary accommodation of refugees that in Chernomorka also held an event dedicated to the holiday. An exhibition of children's drawings contest 'The world in which you live'. Work of participants evaluated eminent artists. Awarding was held in three age categories: 4 to 10 years, 10 to 14 years and from 14 to 18 years. Committee on protection of rights and freedoms of citizens and Charity Fund 'Assalam' dedicated themselves into organization and holding the holiday for children as well, in particular were prepared presents for the winners of children drawing contest such as warm clothes and boots and also there were a table with sweets for all kids from the temporary accommodation of refugees.",

					},
				new_7:
					{
						title: "Sources of happiness",
						date:"13 December 2012",
						text: "Dolphin - is one of the most amazing and mysterious creatures of the planet. Throughout human history, people knew that the dolphins provide assistance drowning and scatter the sharks gathering near the human. Take special care about children. A unique feature of the dolphins is their kindness, sociability, desire to establish a different kind of contact with a person to assist him. In Odessa in 2005 to the International Children's Day was inaugurated Dolphinarium 'Nemo', which was an important event not only for our city, but for the whole south of Ukraine. Over the years the dolphin visited a lot of visitors and residents, and of course most of them are children. One day in July Charity Fund 'Assalam' organized a tour for children in Odessa Dolphinarium 'Nemo'. What did not 'get up' dolphins, seals and white whales. And whirled in the dance, and play ball, and even rolled on a trainer. For each trick children were happily clapping and screaming from pleasure, so that there children, adults no less violently expressing their emotions. After such an idea about, the positive charge should last a long time, because the dolphins and sea lions are so likable that he did not want to leave, but to look more and more. The kids were very pleased with the excursion, thanked the organizers for this opportunity, and Charity Fund 'Assalam' promised that this was not the last tour of this kind.",

					},
				new_8:
					{
						title: "Seminar in Ukraine with Polish experts about people who are searching for shelter",
						date:"13 December 2012",
						text: "October 4, 2012 in Odessa, a seminar was held on the adoption of shelter seekers. The seminar took part in the working visit, the delegation of Polish experts: Radoslav St rizhevskaya MIA Republic of Poland, the Department of Migration Policy, Olga Ghilik Coordinator of the Volunteer Association of Legal Aid, Malgorzata Rafale-Kaminska department for information on countries of origin, the Bureau of foreigners, Violeta Kedzierskaya Department of social assistance, the Bureau of Immigration, Norbert Rafalik head of Administration of the Centre reception of asylum seekers in the White Podlaski Marsiyanik Carolina Department of the asylum procedure, the Bureau of Immigration, Dorota Parzen Foundation President ''Ocalenie'' (Salvation). From the Ukrainian side took part: The Chief of the State Migration Service of Ukraine in Odessa region Tkachuk Sergei Vladimirovich, Deputy Head of Department, Head Office for Refugees PG HMS Ukraine in Odessa region Suprunovsky Ivan Petrovitch director of temporary accommodation of refugees in Odessa, Ilya Malakhov Sergeyevich representatives of the Office for Refugees PG HMS Ukraine in Odessa region. Besides government representatives in the meeting participated various organizations and associations. Representatives of NGO 'Committee on Protection of rights and freedoms of citizens 'Shield' and Charity Fund 'Assalam' ' also visited the event on such a global problem – refugees. Each organization has produced a mini-presentation to tell or show clearly the nature of their activities. All races attended the event had the opportunity to learn about the work of Polish colleagues, share their experiences and exchange views on the above issue. steroids to buy usa",

					},
				new_9:
					{
						title: "Iftar in Odessa",
						date:"13 December 2012",
						text: "Regional public organization “Al Masar” and Islamic Cultural Center in Odessa in headed by Sheikh Imad Abu Alrub organized the dinner or how it’s also called Iftar which in Arabic means the breaking of the fast, the evening meal during the holy month of Ramadan. In this event took part a lot of people among whom were representatives and leaders of various national and cultural societies, Muslim religious leaders of Odessa and even a Sheikh from Egypt. As an invited guest was present the head of the Internal Policy Department of Information and Public Relations of the Odessa City Council Bayzhanov Albert Ivanovich. Opening remarks said Sheikh Imad Abu Alrub, welcomed everyone, highlighted the activities of the Committee on protection of rights and freedoms of citizens “Shield” and Charity Fund “Assalam”. Organizers also prepared video report on the activities of the regional public organization 'Al-Masar' and the Islamic Cultural Center in Odessa. This video shows in detail the robot to these organizations As the last rays of the hid everyone read a pray Al-Maghrib. And then on the tradition they start to brake one’s fast with date on palms and water. Because in the words of the Prophet Muhammad you need to break the fast with date palms and if you do not have them then only with water, because it truly cleans. After the prayers and breaking the fast all the guests all together gathered near the table, where was a lot of different dishes of Arabic national cuisine. Each guest by himself picked the food he wanted. And after all Iftar passed in very hospitable and friendly atmosphere.",

					}
										

			});
			$translateProvider.translations('rus', {			
				menu_title:'Меню',
				menu_home:'Главная',
				menu_about:'О нас',
				menu_news:'Новости',
				menu_gallery:'Галерея',
				menu_video:'Видео',
				menu_contact:'Контакты',
				menu_donation:'Внести пожертвование',
				director:'Директор фонда',
				director_name:'ДОКТОР АЛИЯН МАЗЕН',
				latest_news:'Актуально',
				donate_img:'<img src="img/donate_ru.jpg">',
				logo_img:'<img src="img/name_rus.png">',
				home_text: "«На день нужно смотреть как на маленькую жизнь» - утверждал один известный писатель. Идея создания Благотворительного фонда «Ассалам» возникла с желания сделать дни нашего общества похожими на маленькую жизнь, но Жизнь с большой буквы. Благотворительный фонд «Ассалам» - это неприбыльная благотворительная организация, которая была создана в Одессе в августе 2011 года. Миссия Фонда — творить добро и призывать к этому других не безразличных людей, развивать высокоморальное общество, которое будет основано на принципах духовности и морали, через популяризацию благотворительности и социального партнерства. Люди, которые обращаются к нам, родом из разных уголков нашей необъятной планеты, но объединил их город, уже ставший родным — Одесса. Помогая мы искренне радуемся как дети, потому что имеем возможность сделать мир немного добрее. Если Вы занимаетесь делом, которое спасает чью-то жизнь или судьбу или просто делает жизнь людей лучше, мы готовы помогать Вам. Мы верим, что добрые дела и поступки нужны всем и во все времена!",
				about_text: "Международный благотворительный Фонд «Ассалам» создан с целью содействия полноценному развитию детей, оказания помощи всем нуждающимся, реализации благотворительных программ, направленных на нравственное и интеллектуальное развитие подрастающего поколения, активную работу в сфере образования и здравоохранения. Главная задача фонда - осуществление благотворительной деятельности в интересах общества и отдельных категорий граждан. Нацелены на реализацию программ по созданию бесплатных кружков и спортивных секций как для детей, так и для взрослых. Основатель фонда «Ассалам» искренне желает изменить мир к лучшему, сделать его более добрым и счастливым, способствовать возрождению традиций, провозглашению духовного единства и дружбы всех народов и национальностей. Мы защищаем интересы и помогаем многодетным и малообеспеченным семьям, беженцам из разных стран, не оставляя без внимания талантливое подрастающее поколение, поддерживаем и находим пути для решения проблем бездомных и беззащитных людей. МБФ «Ассалам» активно привлекает все доступные средства массовой информации для поддержки благотворительных проектов и акций, включая ТВ, радио, различные издательские издания. Предметом деятельности является добровольная и бескорыстная деятельность, которая не предусматривает получение дохода от этой деятельности. Оказание гуманитарной помощи малоимущим и многодетным семьям, беженцам. Содействие и оказание значимой помощи детским учреждениям, Домам ребёнка, школам- интернатам и детям, лишенных родительской опеки. Способствуем развитию спорта, туризма , здорового образа жизни и охраны здоровья. Поддержка и развитие талантливой молодёжи. Проведение благотворительных акций, проектов, семинаров, конференций, выставок, а также благотворительных программ и других благотворительных мероприятий. Улучшений материальных условий нуждающихся в благотворительной помощи, содействие социальной реабилитации малоимущих, безработных, инвалидов , других граждан, которые нуждаются в заботе, а также оказание помощи лицам, которые из-за своих физических или других недостатков ограничены в осуществлении своих прав и законных интересов. Сотрудничество и обмен опытом в области благотворительности и социальной деятельности с другими благотворительными организациями.",
				contact_text:"<\span> <\strong>Адрес: Украина, Одесса, ул. Канатная 83, Одесса, Одесская об.- Ильичевск Ул. Данченко 7.<\/strong> <\/span> <\span> <\strong>Телефоны:<\/strong> <\/span> <\span> (+38) 095 902 64 01<\p> (+38) 063 15 32 653 <\/span>  <\span>	 <\strong>E-mail:<\/strong><\p> <\a href='mailto: assalam.fund.charity@gmail.com'>assalam.fund.charity@gmail.com<\/a><\p> assalam-charity.com<\/span><\span><\strong>Реквизиты для безналичного зачисления денег на счет: Международный благотворительный фонд 'АССАЛАМ':<\/strong><\p> Bank: ''Приват Банк''<\p> МФО: 328704<\p> ЕГРПОУ: 2643325277<\p><\p> р/с: 26002054322183 <\/span>",
				enter_sum:'Сумма:',
				currency:"валюта",
				pay:"оплатить",
				donation_make:'Внести пожертвование',
				album_1:'День радио, телевидения и связи.',
				album_2:'День толерантности.',
				album_3:'Митинг против расизма и фашизма в Украине',
				back_gallery:"Галерея",
				new_1: 
					{
						title: "ДЕНЬ ЗАЩИТЫ ДЕТЕЙ",
						date:" 03.06.2014",
						text: '30.05.2014 г. по адресу Пастера, 64 , на кануне международного ДНЯ ЗАЩИТЫ ДЕТЕЙ Международный благотворительный фонд "АССАЛАМ" и "Международный конгресс по защите прав и свобод граждан "ЩИТ" совместно с кафе «EUR-ASIA» организовали детский праздник для детей . Дагер Салех поздравил детей с праздником, для них приготовили различные лакомства , развлекательную программу с клоуном и подарки. Праздник прошел в веселой не принуждённой, обстановке,принес много радости и положительных эмоций как детям так и взрослым, расходились все усталые, но довольные .',

					},
				new_2:
					{
						title: "ШКОЛА БФ 'АССАЛАМ'",
						date:"14.03.2014",
						text: "По инициативе Президента Международного благотворительного фонда «Ассалам» Дагера Салеха Мухамеда,  открылась для всех желающих лингвистическая площадка по изучению украинского, русского, французского, английского и арабского языков. Для того чтобы дети, наряду с украинским и русским языками, владели в той же мере иностранным языком, будь то французский, английский или арабский язык, для иностранцев, беженцев и иммигрантов помощь в изучении украинского и русского языков, для адаптации в нашей стране. На базе лингвистической площадки также открыта школа раннего развития для детей дошкольного возраста, для развития моторики, развитие общих языковых, интеллектуальных, познавательных способностей. Специалисты своего дела с легкостью найдут подход к каждому. Занятия проводятся бесплатно.",

					},
				new_3:
					{
						title: "БФ 'АССАЛАМ' и МКЗПСГ 'ЩИТ' поздравил с 8 марта",
						date:"24.02.2014",
						text: "7 марта на кануне Международного женского дня - 8 марта, президент Международный благотворительный фонд 'АССАЛАМ' и 'Международный конгресс по защите прав и свобод граждан 'ЩИТ'' Дагер Салех Мухамед поздравил представительницы прекрасной половины человечества. Пожелал крепкого здоровья и счастья, а также вручил символические подарки. К поздравлению присоединились: директор Общественного формирования по охране общественного порядка и государственной границы « Спец отряд «Центр» Пантюхин Александр Васильевич, заместитель Чеченской диаспоры Чагаев Салман Хасанович и психолог Конгресса 'ЩИТ' Мищенко Михаил Борисович. Заключительным былом угощение тортом в теплой, дружеской обстановки.",

					},
				new_4:
					{
						title: "'АССАЛАМ' 23-го февраля в гостях в благотворительной организации 'Солнечные дети'",
						date:"24.02.2014",
						text: "23 февраля 2014 года в Одесский городской благотворительной организации помощи детям с синдромом дауна 'Солнечные дети,прошел праздник посвященный Дню защитника Отечества. На праздник был приглашен президент 'Международного конгресса по защите прав и свобод граждан 'ЩИТ'' и Международного благотворительного фонда 'АССАЛАМ' Дагер Салех. Воспитанники этой организации подготовили для гостей сценку 'Красная шапочка', коллективный танец,также сольные номера. Всем участникам праздника вручили поощрительные подарки и организовали сладкий стол.",

					},
				new_5:
					{
						title: "Поздравление Губернатора с наступающим Новым Годом",
						date:"30.12.2013",
						text: "27 декабря 2013 года в Доме приемов состоялось праздничное мероприятие, на котором Губернатор Одесской области Николай Скорик, поздравил всех присутствующих представителей радио, телевидения и связи с наступающим Новым Годом. Пожелал всем в Новом Году счастья, здоровья и творческих успехов. Среди приглашенных гостей были президент Международного конгресса по защите прав и свобод граждан «Щит», Международного благотворительного фонда «Ассалам» Дагер Салех Мухамед. На празднике тихо играл ансамбль скрипачей возле красиво наряженной ёлки, присутствовала теплая атмосфера. После торжественной части все гости продолжили общение за корпоративным фуршетом.",

					},
				new_6:
					{
						title: "Встреча с представителям Центра социальных инициатив «Без границ»",
						date:"09.12.2013",
						text: "06 декабря 2013 года прошла встреча президента Общественной организации Международный конгресс по защите прав и свобод граждан ЩИТ, Международный благотворительный фонд АССАЛАМ Дагера Салеха Мухамеда и представителей Центра Социальных инициатив ,проекта 'Без границ'. На встрече также присутствовал представитель ассоциации дзюдо 'Виктория' Александр Матякин. Во время встречи обсуждались вопросы дальнейшего сотрудничества, перспективы проведения совместных мероприятий. Участники встречи также обсудили инциденты связанные с проявлением фашизма и расизма в отношении студентов - иностранцев ( октябре- ноябре 2013 г.) в городе Одессе, Сумы, Харькове, а также векторе сотрудничества в сфере предупреждения дальнейших подобных ситуаций.",

					},
				new_7:
					{
						title: "МИТИНГ :ПРОТИВ РАСИЗМА И ФАШИЗМА В УКРАИНЕ",
						date:"02.12.2013",
						text: "28 ноября в 12:00 Общественная организация «Международный конгресс по защите прав и свобод граждан «ЩИТ» провела митинг, который был посвящен проблемам фашизма и расизма в Украине по адресу: г. Одесса, ул. Пантелеймоновская, 3, возле Театра музыкальной комедии имени Михаила Водяного. В митинге принимало участие около 100 человек, среди них были представители региональной и республиканской прессы: 8 телеканалов и 5 интернет-изданий. При проведении митинга присутствовала символика к противостоянию фашизма и расизма, как антисоциальным проявлениям. Первым выступал организатор митинга, президент Общественной организации «Международный конгресс по защите прав и свобод граждан «ЩИТ», Благотворительного фонда «Ассалам» Дагер Салех Мухамед. Он обратил внимание, на что в Одессе проживает более 133 национальности. Проявления фашизма и расизма подрывает авторитет Украины и самого города в целом и призвал всех к тому, что в Южной Пальмире необходимо жить и учиться, а не бороться друг с другом. После, к микрофону был приглашен Ю.А. Работин, председатель правления Одесской региональной организации Национального союза журналистов Украины. Он говорил, что обществу не безразлична судьба студентов-иностранцев, что мы уже боролись за свою свободу во Время Второй мировой войны и нам необходимо помнить о социальной солидарности в нашем обществе.",

					},
				new_8:
					{
						title: "БФ 'Ассалам' роздавал обувь",
						date:"19.11.2013",
						text: "Вот уже не первый год Международный благотворительный фонд «Ассалам» спешит на помощь людям, президент Дагер Салех Мухамед и представители которого откликнулись на многие просьбы, за период своего существования, и раздали немало одежды, обуви, медицинских препаратов, канцтоваров, постельного белья, памперсов, детских книг, консервов, фруктов, овощей и многого другого, нуждающимся в помощи. Так и этой осенью Международный благотворительный фонд «Ассалам» раздавал женскую обувь. 7 ноября 2013 года представители Международного благотворительного фонда «Ассалам» посетили находящихся в школе-интернате № 3 детей с заболеваниями сердечно-сосудистой системы и подарили им обувь. Так же обувь была роздана Центру детского и юношеского творчества «Проминь», Ассоциации борьбы дзюдо «Виктория», Благотворительного фонду «Молодой инвалид», Одесской региональной организации Национального союза журналистов Украины и Южному оперативному казачьему округу. Приходили все желающие: пожилые люди, семьи беженцев и смешанные семьи. Получившие обувь люди, приводили с собой друзей и знакомых, никто не ушел с пустыми руками. Не стоит забывать, добро добром откликнется!",

					},
				new_9:
					{
						title: "День радио, телевидения и связи.",
						date:" 19.11.2013",
						text: "16 ноября 2013 года, президент Международного конгресса по защите прав и свобод граждан «Щит» и Международного благотворительного фонда «Ассалам», Дагер Салех Мухамед, совместно с председателем правления Одесской региональной организации Национального союза журналистов Украины, Работиным Юрием Анатольевичем, торжественно поздравили работников радио, телевидения и связи с профессиональным праздником. Присутствующим представителям данных профессий были вручены подарки, цветы, грамоты и листы благодарности, а так же был накрыт праздничный стол. Мероприятие состоялось в офисе Одесской региональной организации Национального союза журналистов Украины, на данном празднике были порядка десяти ведущих телекомпаний, было сказано много теплых слов и поздравлений.",

					}				
			});

			$translateProvider.translations('ar', {			
				menu_title:'القائمة',
				menu_home:'منزل',
				menu_about:'حول بنا',
				menu_news:'أخبار',
				menu_gallery:'معرض',
				menu_video:'فيديو',
				menu_contact:'اتصل',
				menu_donation:'بالتبرع',
				director:'مدير',
				// director_name:'عليان    مازن   .د',
				director_name:'د. مازن  عليان',
				latest_news:'آخر الأخبار',
				donate_img:'<img src="img/donate_ar.jpg">',
				logo_img:'<img src="img/name_ar.png">',
				home_text:" 'حالفني الحظ بأن أكون قادرا على إهداء البهجة للأطفال و جميع المحتاجين. نحن جميعا مختلفين و بهذا نكمل بعضنا البعض... و لكننا متساويين في شيء واحد: كل منا يحاول أن يجعل الجميع مبتهجين و سعداء.لدي بفضل الجمعية اتصال بأناس مختلفين و ممتعين و أنا واثق تماما بأنه يوجد العديد من الناس المستعدين لتقديم المساعدة في عالمنا الحالي. أريد أن نجعل معا هذا العالم أفضل و أن يتربى الأطفال في جو من الحب و اللطف و السلام و السعادة. يجب أن نسعى جميعا لهذا الشيء و يجب أن لا نفقد الأمل بمقدرتنا على بناء مستقبل مشرق و حياة إيجابية لجيلنا الحالي.'صالح محمد ظاهر – رئيس الجمعية الخيرية 'السلام' حول الجمعية:جمعية مدنية اجتماعية خيرية انسانية غير ربحية ولا حزبية مستقلة باهدافها وتوجيهاتها وعملها خدمة الانسان ومساعدة المحتاج ونشر البسمة على وجوه الاطفال اليتامى والمعاقيين والمرضى المسنيين والمهاجريين واللاجئيين انشات جمعية السلام لبث روح الافة والتسامح وترسيخ سلوك التعاون الخيري بعيدا عن التعصب الديني والفكري بعيدا عن الحقد والكراهية ونشر ثقافة السلام في العالم واحترام معتقدات وتراث اي شعب كانأنشأت الجمعية الخيرية 'السلام' بهدف المساعدة في التنمية الكاملة للأطفال و تقديم المساعدة لجميع المحتاجين و تنفيذ المشاريع الخيرية الهادفة إلى التنمية الأخلاقية و الفكرية لجيل الشباب و تنفيذ العمل الفعال في مجالات التعليم و الصحة العامة. الهدف الأساسي للجمعية هو ممارسة النشاط الخيري لصالح المجتمع بشكل عام و لصالح مجموعات محددة من المواطنين بشكل خاص.تهدف الجمعية إلى تنفيذ البرامج المتعلقة بتأسيس حلقات مجانية و صفوف رياضية للأطفال و الكبار. يتمنى مؤسسو جمعية 'السلام' إلى تغيير العالم إلى الأحسن و جعله أكثر لطفا و سعادة و المساعدة في إحياء العادات و إعلان الوحدة الروحية و الصداقة بين جميع الشعوب و القوميات. نحن ندافع عن المصالح و نساعد الأسر الكبيرة و الفقيرة و اللاجئين من مختلف دول العالم و لا نترك الجيل الشاب الموهوب بلا اهتمام و ندعم و نجد الحلول للأشخاص بلا مأوى و الأشخاص المحتاجين للحماية. تقوم الجمعية الخيرية 'السلام' باستخدام جميع وسائل الإعلام المتاحة بما فيها التلفزيون و الراديو و جميع وسائل النشر من اجل دعم المشاريع و الحملات الخيرية.الهدف من الجمعية هو ممارسة النشاط الطوعي و النزيه و الذي لا يؤمن أي دخل ناتج عن ممارسة هذا النشاط. تقديم المساعدات الإنسانية للأسر الفقيرة و الكبيرة و اللاجئين. المساعدة في تقديم المساعدات للمؤسسات الراعية للطفولة و دور الأيتام و المدارس الداخلية و الأطفال المحرومين من رعاية الوالدين. نساعد في تنمية الرياضة و السياحة و نمط الحياة الصحي و حماية الصحة. نقوم بدعم و تنمية المواهب الشابة. نقوم بإجراء المشاريع و المؤتمرات و حلقات البحث و المعارض الخيرية و إجراء البرامج الخيرية و غيرها من الأمور المتعلقة بمجال العمل الخيري. تحسين الأحوال الاقتصادية للمحتاجين في المساعدات الخيرية و نقوم بدعم إعادة تأهيل الفقراء و أشخاص بلا عمل و المعاقين و غيرهم من المواطنين الذين يحتاجون إلى الاهتمام و نقوم بتقديم المساعدات للأشخاص الذين بسبب النقص الفيزيائي أو أي نقص أخر محددون في تنفيذ حقوقهم و مصالحهم القانونية. نقوم بالمشاركة و تبادل الخبرة في مجال الأعمال الخيرية و النشاط الاجتماعي مع المنظمات الخيرية الأخرى.",
				about_text: " جمعية السلام الخيرية 'حالفني الحظ بأن أكون قادرا على إهداء البهجة للأطفال و جميع المحتاجين. نحن جميعا مختلفين و بهذا نكمل بعضنا البعض... و لكننا متساويين في شيء واحد: كل منا يحاول أن يجعل الجميع مبتهجين و سعداء. لدي بفضل الجمعية اتصال بأناس مختلفين و ممتعين و أنا واثق تماما بأنه يوجد العديد من الناس المستعدين لتقديم المساعدة في عالمنا الحالي. أريد أن نجعل معا هذا العالم أفضل و أن يتربى الأطفال في جو من الحب و اللطف و السلام و السعادة. يجب أن نسعى جميعا لهذا الشيء و يجب أن لا نفقد الأمل بمقدرتنا على بناء مستقبل مشرق و حياة إيجابية لجيلنا الحالي.' صالح محمد ظاهر – رئيس الجمعية الخيرية 'السلام' حول الجمعية:جمعية مدنية اجتماعية خيرية انسانية غير ربحية ولا حزبية مستقلة باهدافها وتوجيهاتها وعملها خدمة الانسان ومساعدة المحتاج ونشر البسمة على وجوه الاطفال اليتامى والمعاقيين والمرضى المسنيين والمهاجريين واللاجئيينانشات جمعية السلام لبث روح الافة والتسامح وترسيخ سلوك التعاون الخيري بعيدا عن التعصب الديني والفكري بعيدا عن الحقد والكراهية ونشر ثقافة السلام في العالم واحترام معتقدات وتراث اي شعب كان أنشأت الجمعية الخيرية 'السلام' بهدف المساعدة في التنمية الكاملة للأطفال و تقديم المساعدة لجميع المحتاجين و تنفيذ المشاريع الخيرية الهادفة إلى التنمية الأخلاقية و الفكرية لجيل الشباب و تنفيذ العمل الفعال في مجالات التعليم و الصحة العامة.الهدف الأساسي للجمعية هو ممارسة النشاط الخيري لصالح المجتمع بشكل عام و لصالح مجموعات محددة من المواطنين بشكل خاص. تهدف الجمعية إلى تنفيذ البرامج المتعلقة بتأسيس حلقات مجانية و صفوف رياضية للأطفال و الكبار. يتمنى مؤسسو جمعية 'السلام' إلى تغيير العالم إلى الأحسن و جعله أكثر لطفا و سعادة و المساعدة في إحياء العادات و إعلان الوحدة الروحية و الصداقة بين جميع الشعوب و القوميات. نحن ندافع عن المصالح و نساعد الأسر الكبيرة و الفقيرة و اللاجئين من مختلف دول العالم و لا نترك الجيل الشاب الموهوب بلا اهتمام و ندعم و نجد الحلول للأشخاص بلا مأوى و الأشخاص المحتاجين للحماية. تقوم الجمعية الخيرية 'السلام' باستخدام جميع وسائل الإعلام المتاحة بما فيها التلفزيون و الراديو و جميع وسائل النشر من اجل دعم المشاريع و الحملات الخيرية. الهدف من الجمعية هو ممارسة النشاط الطوعي و النزيه و الذي لا يؤمن أي دخل ناتج عن ممارسة هذا النشاط. تقديم المساعدات الإنسانية للأسر الفقيرة و الكبيرة و اللاجئين. المساعدة في تقديم المساعدات للمؤسسات الراعية للطفولة و دور الأيتام و المدارس الداخلية و الأطفال المحرومين من رعاية الوالدين. نساعد في تنمية الرياضة و السياحة و نمط الحياة الصحي و حماية الصحة. نقوم بدعم و تنمية المواهب الشابة. نقوم بإجراء المشاريع و المؤتمرات و حلقات البحث و المعارض الخيرية و إجراء البرامج الخيرية و غيرها من الأمور المتعلقة بمجال العمل الخيري. تحسين الأحوال الاقتصادية للمحتاجين في المساعدات الخيرية و نقوم بدعم إعادة تأهيل الفقراء و أشخاص بلا عمل و المعاقين و غيرهم من المواطنين الذين يحتاجون إلى الاهتمام و نقوم بتقديم المساعدات للأشخاص الذين بسبب النقص الفيزيائي أو أي نقص أخر محددون في تنفيذ حقوقهم و مصالحهم القانونية. نقوم بالمشاركة و تبادل الخبرة في مجال الأعمال الخيرية و النشاط الاجتماعي ",
				contact_text: '<\iframe src="http://maps.google.com.ua/maps/ms?msa=0&amp;msid=202481431564987969310.0004aad7e0ef14d93a964&amp;ie=UTF8&amp;vpsrc=6&amp;ll=46.472892,30.734425&amp;spn=0.008867,0.017166&amp;z=15&amp;output=embed" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" width="400" height="300"><\/iframe>',
				enter_sum:'أدخل المبلغ:',
				currency:"عملة",
				pay:'دفع',
				donation_make:'بالتبرع',
				album_1:'День радио, телевидения и связи.',
				album_2:'День толерантности.',
				album_3:'Митинг против расизма и фашизма в Украине',
				back_gallery:"الصفحة الرئيسية",
				new_1: 
					{
						title: "لقاء مع رئيس الدولة HMS من أوكرانيا في منطقة أوديسا",
						date:" 03.06.2014",
						text: 'عقدت 25 يناير 2013 اجتماع لمجلس ممثلي المنظمات العامة والوطنية - الجماعات الثقافية مع رئيس الدولة HMS من أوكرانيا في منطقة أوديسا Tkachyk SV ورئيس الدولة في حالات اللاجئين والأجانب Tkachyk OV ناقشنا وجهات نظر أخرى الرفقة، تماما على أسئلة الدعم لبرامج الصندوق "الرحمة" في العمل مع الأطفال اللاجئين، أسئلة إشكالية مع تسجيل اللاجئين والسعي لمنزل. ممثلة لجنة حماية حقوق وحريات المواطنين "الدرع" والخيرية صندوق "السالم" الرئيس ضاهر صالح محمد وقال عن أنشطة المنظمة.',

					},
				new_2:
					{
						title: "الاحتفال برأس السنة الجديدة في الإقامة المؤقتة للاجئين",
						date:"14.03.2014",
						text: "تقليد الاحتفال بالعام الجديد مع الأخذ انها جذور من القرون القديمة. الأهم من ذلك كله هذا العيد ينتظرون الأطفال، ولكن هذا ليس من المستغرب، لأنه إذا جعل الرغبة في ليلة رأس السنة الجديدة، بعد ذلك سوف يتحقق. لجميع الاطفال الذين كانوا بصحة جيدة على مدار العام يأتي سانتا كلوز مع الهدايا. لذلك قرر ممثلين عن لجنة المنظمات العامة في حماية حقوق وحريات المواطنين الدرع و السالم الصندوق الخيري برئاسة الرئيس ضاهر صالح محمد عدم الخروج عن التقاليد ويوم 26 ديسمبر، وجاء عام 2012 مع الهدايا للالجديد الاحتفال برأس السنة في مساكن مؤقتة للاجئين بسبب عدم العيش مع أسرهم 30 أطفال من جميع الأعمار. برنامج الحفل تنظمها وتديرها المواهب الشابة من مدرسة الإبداع في إيليتشيفسك. في الامتنان لسكان الحفل والحلويات الشباب يؤديها مع الرقصات في الأزياء التقليدية. مع نظمت بمساعدة من اللجنة ومؤسسة للأطفال الجدول الحلو، حيث بعد وقوع الحدث يمكنك أن تأكل كل أنواع الأشياء الجيدة.",

					},
				new_3:
					{
						title: "الاحتفال برأس السنة الجديدة في مركز الطفل شباب الإبداع 'PROMIN'",
						date:"24.02.2014",
						text: "25 ديسمبر 2012 في مركز لحزب السنة الجديدة للأطفال الإبداع الشباب 'PROMIN' عقد. التلاميذ مع معلميهم تنظيم حفل موسيقي للضيوف وأولياء الأمور. أيضا في مهرجان حضره الأطفال الذين يذهبون إلى المدرسة في التطور المبكر للالسالم الصندوق الخيري. أنها تتمتع يراقب المشهد، لأن المشهد كان كثير جنية شخصيات القصص، وسانتا كلوز مع نظيره Snegoruchkoy وبابا ياجا مع frights وغيرها من الأشخاص على حد سواء المعروفة. وأدلى ممثلو لجنة حماية حقوق وحريات المواطنين درع و السالم صندوق مساعدة كبيرة في تنظيم هذا الحدث، ما فعلوه بالضبط قدموا هدايا حلوة للأطفال.",

					},
				new_4:
					{
						title: "دعونا مساعدة الشعب الفلسطيني معا",
						date:"24.02.2014",
						text: "منظمة عامة لجنة حماية حقوق وحريات المواطنين درع '' والصندوق الخيري السالم في رأس الرئيس ضاهر صالح والجميع لا مبال في 18 ديسمبر 2012 تنظيم هذا العمل في أوديسا. وخصص الهدف من إجراءات لحماية الشعب الفلسطيني الذي يعيش على أرض سوريا. 16 ديسمبر 2012 صدر عن معسكر سلاح الجو السوري اليرموك صاروخين على الاقل، واحدة منها ضرب المسجد، الذي كان آنذاك وإيواء اللاجئين الفلسطينيين. عدد من غارة جوية قاتلة على المخيم، حيث حوالي 100،000 لاجئ فلسطيني، كان 25 شخصا على الأقل، ناهيك عن الجرحى. والمزيد والمزيد من الضحايا الفلسطينيين يسعون للحصول على المساعدة. يتم تدمير المنازل ليس فقط، ولكن أيضا مرافق اجتماعية - المستشفيات والمدارس والمخابز. هناك هجمات مستمرة على المباني الصناعية ومحطات توليد الكهرباء. وتسعى السلطات جاهدة للتعامل مع التدخلات الصحية الأساسية. يبدأ الجوع. نقص الوقود في فصل الشتاء، يؤدي ذلك إلى حقيقة أن الناس تجميد عاديا في المناطق القارسة، لا يمكن طهي وجبة ساخنة. لجنة حماية حقوق وحريات المواطنين درع للأعمال الخيرية وصندوق السالم رسائل مستعدة وإرسالها إلى اللجنة الدولية للصليب الأحمر ومكتب المفوض السامي لشؤون اللاجئين، ومنظمة الأمم المتحدة (UNHCR) لتحويل أخيرا من الانتباه إلى الشعب الفلسطيني، الذين يعانون ببراءة في",

					},
				new_5:
					{
						title: "زيارة مع اللجنة في Chernomorskaya مستعمرة جزائية № 74",
						date:"30.12.2013",
						text: "25 أكتوبر 2012 رئيس المنظمة العامة لجنة حماية حقوق وحريات المواطنين درع و السالم الصندوق الخيري بالتعاون مع اللجنة الدولية لحماية حقوق الإنسان في شخص رئيس جورج Shibanov في زارت لجنة مستعمرة النساء Chernomorskaya والجزائية № 74. على سبيل الموضوعية وحضر لجنة من ممثلي مختلف الجهات الحكومية والمؤسسات العامة. وكان السبب الرئيسي لزيارة المعلومات التي يزعم احتواء النساء في ظروف غير إنسانية، للتخويف، والأمهات الشابات، كإجراء تأديبي، لا تدع الأطفال الذين هم في دار الأطفال في المستعمرة. وكان المركز الأول من قبل لجنة زار البيت للطفل في المستعمرة. في هذه المرحلة من أنه يسكن 79 طفلا تقل أعمارهم عن 3 سنوات. وبطبيعة الحال فإن أول ما يلفت انتباهك هو نظافة مثالية والنظام الذي كان سائدا في جميع المجالات، سواء كانت سكنية أو الأعمال. كان قادرا على التحدث مع موظفي خدمة بيت الطفل، معرفة المزيد عن حياة الأطفال. ويسمح للسجينات لرؤية أطفالهن مرتين في اليوم لمدة ساعتين. بقية الوقت كانوا يشاركون مع المربين وعلماء النفس والممرضات. إذا كان ذلك ممكنا، مع مساعدة من رعاة لقيادة الأطفال في رحلات، إلى السيرك والدلافين. وعلى كل عطلة يتم تنظيم الحفلات النهارية، وبطبيعة الحال، مع الهدايا والمسابقات. لقد اللجنة مع الزيارة في الوقت الذي أمهات كانوا يسيرون مع أطفالهم. الأطفال يشكل بكل سرور للحصول على صور وكاميرات التلفزيون. دون أي حرج ذهبت إلى أيدي الضيوف. من كلام الأمهات، أصبح من الواضح أنها هادئة في حين أن الأطفال هم هنا بالنسبة لهم، وأنه معهم وشيئا سيئا يحدث. وبعد تتبع اللجنة إلى مكتبة مستعمرة. وتقول أمينة مكتبة مارينا يقرأون كل شيء تقريبا، والعديد من المنظمات تنقل الصحف والكتب. هناك معرضا لأعمال الأسرى، وتجدر الإشارة إلى أن معظمهم من الثناء. لم تجاهل ومباشرة تلك الأماكن التي تكون فيها المرأة ينامون ويقضون وقتهم خارج ساعات الدوام. فاجأ ورقة بيضاء وترتيب الأسرة المثالية. كما زار أعضاء اللجنة مستشفى للمستعمرة. جميع الأسئلة التي أجاب المهتمة لجنة رئيس مسؤول Chernomorskaya مستعمرة جزائية № 74 كراكاي أولغا Nikolaevna. وأكد أنه إذا كانوا يريدون أن تتكرر مثل هذه التجربة في أي يوم وفي أي وقت من اليوم لاستقر أخيرا الشائعات الغريبة وتتهم حول المعاملة غير الإنسانية للسجينات.",

					},
				new_6:
					{
						title: "يوم الطفل العالمي",
						date:"09.12.2013",
						text: "في عام 1954، أوصت الجمعية العامة أن جميع البلدان لوضع موضع التنفيذ في الاحتفال باليوم العالمي للطفل بوصفه يوما من الأخوة والتفاهم الأطفال على الأنشطة التي تهدف إلى رفاهية الأطفال في جميع أنحاء العالم العالم. دعت الأمم المتحدة الحكومات إلى الاحتفال بهذا اليوم في أي يوم أن له ما يبرره كل منهم. 20 نوفمبر يصادف اليوم الذي اعتمدت الجمعية في عام 1959 إعلان حقوق الطفل، وفي عام 1989 - اتفاقية حقوق الطفل. في مساكن مؤقتة للاجئين أن في Chernomorka عقدت أيضا حدث مخصص لقضاء العطلة. معرض لرسومات الأطفال مسابقة العالم التي تعيش فيها. العمل من المشاركين تقييم الفنانين البارزين. عقدت منح في ثلاث فئات العمرية: 4-10 سنة، 10-14 سنة و14-18 سنة. لجنة حماية حقوق وحريات المواطنين و السالم الصندوق الخيري مكرسة نفسها في تنظيم وعقد عطلة للأطفال أيضا، على وجه الخصوص أعدت الهدايا للفائزين من الأطفال مسابقة الرسم مثل الملابس والأحذية الدافئة وأيضا كانت هناك طاولة مع الحلويات لجميع الأطفال من أماكن الإقامة المؤقتة للاجئين.",

					},
				new_7:
					{
						title: "مصادر السعادة",
						date:"02.12.2013",
						text: "دولفين - هو واحد من أكثر المخلوقات المدهشة والغامضة للكوكب. على مر التاريخ البشري، يعرف الناس أن الدلافين توفر الغرق المساعدة وتتناثر جمع بالقرب من الإنسان أسماك القرش. عناية خاصة عن الأطفال. وهناك ميزة فريدة من الدلافين هي من اللطف ومؤانسة، والرغبة في إقامة نوع مختلف من الاتصال مع شخص لمساعدته. في أوديسا في عام 2005 ليوم الطفل العالمي افتتح دولفيناريوم نيمو، الذي كان حدثا هاما ليس فقط لمدينتنا، ولكن بالنسبة للجنوب كله من أوكرانيا. على مر السنين زار الدلفين الكثير من الزوار والمقيمين، وطبعا معظمهم من الأطفال. يوم واحد في السالم الصندوق الخيري يوليو نظمت جولة للأطفال في أوديسا دولفيناريوم نيمو. ما لم أستيقظ الدلافين والفقمة والحيتان البيضاء. وهامت في الرقص، ولعب الكرة، وحتى توالت على مدرب. لكل خدعة الأطفال كانوا يصفقون لحسن الحظ ويصرخ من المتعة، حتى لا يكون هناك أطفال والبالغين يعبرون عن ما لا يقل بعنف عواطفهم. بعد هذه الفكرة حول، ينبغي أن شحنة موجبة تستمر لفترة طويلة، لأن الدلافين وأسود البحر ومحبب لدرجة أنه لا يريد أن يغادر، ولكن للنظر أكثر وأكثر. وكان الأطفال سعداء جدا مع رحلة، شكر المنظمين على هذه الفرصة، والصندوق الخيري السالم وعدت أن هذا لم يكن الجولة الأخيرة من هذا النوع.",

					},
				new_8:
					{
						title: "ندوة في أوكرانيا مع خبراء البولندي عن الناس الذين يبحثون عن مأوى",
						date:"19.11.2013",
						text: "4 أكتوبر 2012 في أوديسا، عقدت ندوة حول اعتماد الباحثين عن مأوى. عقدت الندوة جزء في زيارة عمل لوفد من الخبراء البولندي: رادوسلاف سانت rizhevskaya جمهورية MIA من بولندا، وإدارة سياسات الهجرة، منسق أولغا Ghilik للجمعية التطوعية المساعدة القانونية، قسم مالجورزاتا رافال-Kaminska للحصول على معلومات حول دول الأصل، مكتب الأجانب، فيوليتا زارة Kedzierskaya المساعدة الاجتماعية، ومكتب الهجرة، رئيس نوربرت Rafalik الإدارة لاستقبال مركز لطالبي اللجوء في الأبيض بودلاسكي زارة Marsiyanik كارولينا من إجراءات اللجوء، مكتب الهجرة، دوروتا Parzen رئيس مؤسسة '' Ocalenie '' (الخلاص). من اتخذ الجانب الأوكراني جزء: إن رئيس دائرة الهجرة دولة أوكرانيا في منطقة أوديسا تكاتشوك سيرغي فلاديميروفيتش، نائب رئيس قسم، رئيس مكتب لشؤون اللاجئين PG HMS أوكرانيا في منطقة أوديسا مدير Suprunovsky إيفان بتروفيتش الإقامة المؤقتة للاجئين في أوديسا، ايليا مالاخوف سيرجيفيتش ممثلي مكتب لشؤون اللاجئين PG HMS أوكرانيا في منطقة أوديسا. إلى جانب ممثلي الحكومة في الاجتماع شاركت المنظمات والجمعيات المختلفة. كما زار ممثلي المنظمات غير الحكومية لجنة حماية حقوق وحريات المواطنين درع والصندوق الخيري السالم 'الحدث على هذه المشكلة العالمية - لاجئ. وقد أنتجت كل منظمة على بعد العرض مصغرة لأقول أو تظهر بوضوح طبيعة أنشطتها. وحضر جميع الأجناس كان الحدث فرصة للتعرف على عمل الزملاء البولندي، وتبادل الخبرات، وتبادل وجهات النظر حول هذه القضية المذكورة أعلاه. المنشطات لشراء الولايات المتحدة الأمريكية",

					},
				new_9:
					{
						title: "الإفطار في أوديسا",
						date:" 19.11.2013",
						text: "منظمة عامة إقليمية آل مسار والمركز الثقافي الإسلامي في أوديسا في يرأسها الشيخ عماد أبو الرب نظمت عشاء أو كيف يسمى أيضا الإفطار الذي يعني في العربية للكسر بسرعة، وجبة العشاء خلال شهر رمضان المبارك. في استغرق هذا الحدث جزءا كان هناك الكثير من الناس من بينهم ممثلي وقادة المجتمعات الوطنية والثقافية المختلفة، والزعماء الدينيين المسلمين في أوديسا وحتى الشيخ من مصر. كما كان ضيف مدعو الحالي رئيس قسم السياسة الداخلية من المعلومات والعلاقات العامة في مجلس مدينة أوديسا Bayzhanov ألبرت إيفانوفيتش. وقالت كلمته الافتتاحية رحب الشيخ عماد أبو الرب، والجميع، سلط الضوء على أنشطة لجنة حماية حقوق وحريات المواطنين درع للأعمال الخيرية وصندوق السالم. أعد المنظمون أيضا تقرير مصور عن أنشطة المنظمة العامة الإقليمية آل مسار والمركز الثقافي الإسلامي في أوديسا. هذا الفيديو يبين بالتفصيل الروبوت لهذه المنظمات والأشعة الأخيرة من الجميع اختبأ يقرأون الصلاة آل صلاة المغرب. ثم على التقليد أنها بداية لالفرامل الصيام مع التاريخ النخيل والمياه. لأنه في قول النبي محمد تحتاج إلى يفطر مع أشجار النخيل، وإذا لم يكن لديك لهم بعد ذلك إلا بالماء، لأنه ينظف حقا. بعد الصلاة والافطار جميع الضيوف كل مجتمعين بالقرب من طاولة، حيث كان الكثير من أطباق مختلفة من المأكولات الوطني العربية. كل ضيف بنفسه اختار الطعام أراد. وبعد تمرير كافة الإفطار في جو مضياف ودية للغاية.",

					}		
			});

			// $translateProvider.useSanitizeValueStrategy('escape');
			$translateProvider.preferredLanguage('en');



	}]);

	app.controller('Ctrl', ['$scope', '$translate', function($scope, $translate, $http){
		$scope.changeLanguage = function(key){
			$translate.use(key);
		};

	}]);
	
	app.controller("NewsController", function(){
		this.articles = news;
	});
		var news = [
			{
				title: "Meeting with the Chief State HMS of Ukraine in Odessa region",
				date:"13 March 2013",
				text: '25 January 2013 was held a meeting of the Council of the representatives of public organizations and nationally- cultural communities with the Chief State HMS of Ukraine in Odessa region Tkachyk S. V. and Chief State in cases of refugees and foreigners Tkachyk O. V. We discussed the perspectives of further companionship, exactly the questions of the support of the programs of the fund “Compassion” in the work with the children of refugees, problematic questions with registration of refugees and seeking for a household. Committee on Protection of Rights and Freedoms of citizens “Shield” and the Charity Fund “Assalam” represented the President Daher Saleh Mohammad and he told about the activities of the organization.',

			},
			{
				title: "New Year celebration in temporary accomodation of refugees",
				date:"24 January 2013",
				text: "The tradition of celebration of New Year taking it's roots from old centuries. Most of all this holiday are waiting children, but this is not surprising, because if you make a wish on New Year's night, then it will come true. To all the kids who were doing well throughout the year comes Santa Claus with gifts. So the representatives of Public organization Committee on the protection of rights and freedoms of citizens 'The Shield' and Charity Fund 'Assalam' headed by the President Daher Saleh Muhammad decided not to depart from tradition and on 26 December, 2012 came with gifts for New Year celebration at the temporary accommodation of refugees because there live with their families 30 kids of all ages. The concert program organized and conducted by young talents of a school of creativity in Illichivsk. In gratitude for the concert and sweets young inhabitants performed with a dances in traditional costumes. With the help of the Committee and the Foundation for Children was organized sweet table, where after the event you can eat all sorts of goodies.",

			},
			{
				title: "New Year celebration at the Center for Children's Youth Creativity 'Promin'",
				date:"24 January 2013",
				text: "December 25, 2012 at the Center for Children's Youth Creativity 'Promin' New Year party was held. Pupils together with their teachers organized a concert for the guests and parents. Also at the festival was attended by kids who attend school in the early development of the Charity Fund 'Assalam'. They enjoyed watching the scene, because the scene had a lot fairy tale characters, and Santa Claus with his Snegoruchkoy and Baba Yaga with frights and other equally well-known characters. The representatives of Committee on protection of rights and freedoms of citizens 'Shield' and Fund 'Assalam' made a huge help in organization of the event, what they did exactly they gave sweet presents for children.",

			},
			{
				title: "Let's help Palestinian people together",
				date:"24 January 2013",
				text: "Public organization 'Committee on protection of rights and freedoms of citizens 'Shield' ' and Charity Fund 'Assalam' in a head of President Daher Saleh and everyone not indifferent on December 18, 2012 organized an action in Odessa. The aim of the action was dedicated to the protection of Palestinian people who live on the territory of Syria. December 16, 2012 released by the Syrian air force camp 'Yarmuk' at least two missiles, one of which hit the mosque, which was then sheltering Palestinian refugees. Number of fatal air strike on camp, where about 100,000 Palestinian refugees, was at least 25 people, not to mention the wounded. More and more Palestinian victims are seeking for help. Are destroyed not only homes, but also social facilities - hospitals, schools, bakeries. There are constant attacks on industrial buildings and power plants. Authorities are struggling to cope with basic health interventions. Begins hunger. Shortages of fuel in winter, lead to the fact that people are freezing banal in unheated areas, can not cook a hot meal. Committee on protection of rights and freedoms of citizens 'Shield' and Charity Fund 'Assalam' prepared and sent letters to The International Committee of the Red Cross and the Office of the High Commissioner for Refugees, the United Nations (UNHCR) to finally turn their attention to Palestinian people, who are innocently suffering in ",

			},
			{
				title: "Visit with the Commission in Chernomorskaya penal colony № 74",
				date:"13 December 2012",
				text: "October 25, 2012 the president of public organization the Committee on protection of rights and freedoms of citizens 'Shield' and the Charity Fund 'Assalam' together with the International Committee for the Protection of Human Rights in the person of the chairman George Shibanov in the commission visited the Chernomorskaya women's penal colony № 74. For objectivity the commission was attended by representatives of various government and public organizations. The main reason for the visit was the information that allegedly contain women in inhuman conditions, bullied, and young mothers, as a disciplinary measure, do not let their children who are in the children's home in the colony. The first place visited by the commission was the House of the child in the colony. At this point in it dwells 79 children under the age of 3 years. Of course the first thing that catches your eye is perfect cleanliness and order that prevailed in all areas, whether residential or chores. Was able to talk to service personnel of House of the child, learn more about the life of children. Women prisoners are allowed to see their children twice a day for two hours. Rest of the time they are engaged with educators, psychologists and nurses. If possible, with the help of patrons to lead children on trips, to the circus and a dolphinarium. And on every holiday matinees are organized, of course, with gifts and competitions. Commission has been with the visit at a time when mothers were walking with their children. Kids gladly posed for pictures and television cameras. Without any embarrassment went to the hands of the guests. From the words of mothers, it became clear that they are quiet while their children are here for them, and that with them nothing bad will happen. After the Commission followed to the library of the colony. Librarian Marina says they read almost everything, and many organizations transfer their newspapers and books. There is an exhibition of the work of prisoners, it should be noted that most of them are commendable. Have not ignored and directly those premises where women are sleeping and spending their time during off hours. Surprised the white sheets and perfect made beds. Also, members of the commission visited hospital of the colony. All the questions that interested the Commission answered responsible chief of Chernomorskaya penal colony № 74 Karakaj Olga Nikolaevna. Assured that if they want such a test could be repeated on any day at any time of the day to finally was settled strange and accusing rumors about inhuman treatment of women prisoners.",

			},
			{
				title: "Universal children's day",
				date:"13 December 2012",
				text: "In 1954, the General Assembly recommended that all countries to put into practice the celebration of Universal Children's Day as a day of world brotherhood and understanding of children on the activities aimed at the welfare of children around the world. UN invited governments to celebrate this day on any day that each of them is justified. November 20 marks the day on which the Assembly adopted in 1959 the Declaration on the Rights of the Child, and in 1989 - the Convention on the Rights of the Child. In temporary accommodation of refugees that in Chernomorka also held an event dedicated to the holiday. An exhibition of children's drawings contest 'The world in which you live'. Work of participants evaluated eminent artists. Awarding was held in three age categories: 4 to 10 years, 10 to 14 years and from 14 to 18 years. Committee on protection of rights and freedoms of citizens and Charity Fund 'Assalam' dedicated themselves into organization and holding the holiday for children as well, in particular were prepared presents for the winners of children drawing contest such as warm clothes and boots and also there were a table with sweets for all kids from the temporary accommodation of refugees.",

			},
			{
				title: "Sources of happiness",
				date:"13 December 2012",
				text: "Dolphin - is one of the most amazing and mysterious creatures of the planet. Throughout human history, people knew that the dolphins provide assistance drowning and scatter the sharks gathering near the human. Take special care about children. A unique feature of the dolphins is their kindness, sociability, desire to establish a different kind of contact with a person to assist him. In Odessa in 2005 to the International Children's Day was inaugurated Dolphinarium 'Nemo', which was an important event not only for our city, but for the whole south of Ukraine. Over the years the dolphin visited a lot of visitors and residents, and of course most of them are children. One day in July Charity Fund 'Assalam' organized a tour for children in Odessa Dolphinarium 'Nemo'. What did not 'get up' dolphins, seals and white whales. And whirled in the dance, and play ball, and even rolled on a trainer. For each trick children were happily clapping and screaming from pleasure, so that there children, adults no less violently expressing their emotions. After such an idea about, the positive charge should last a long time, because the dolphins and sea lions are so likable that he did not want to leave, but to look more and more. The kids were very pleased with the excursion, thanked the organizers for this opportunity, and Charity Fund 'Assalam' promised that this was not the last tour of this kind.",

			},
			{
				title: "Seminar in Ukraine with Polish experts about people who are searching for shelter",
				date:"13 December 2012",
				text: "October 4, 2012 in Odessa, a seminar was held on the adoption of shelter seekers. The seminar took part in the working visit, the delegation of Polish experts: Radoslav St rizhevskaya MIA Republic of Poland, the Department of Migration Policy, Olga Ghilik Coordinator of the Volunteer Association of Legal Aid, Malgorzata Rafale-Kaminska department for information on countries of origin, the Bureau of foreigners, Violeta Kedzierskaya Department of social assistance, the Bureau of Immigration, Norbert Rafalik head of Administration of the Centre reception of asylum seekers in the White Podlaski Marsiyanik Carolina Department of the asylum procedure, the Bureau of Immigration, Dorota Parzen Foundation President ''Ocalenie'' (Salvation). From the Ukrainian side took part: The Chief of the State Migration Service of Ukraine in Odessa region Tkachuk Sergei Vladimirovich, Deputy Head of Department, Head Office for Refugees PG HMS Ukraine in Odessa region Suprunovsky Ivan Petrovitch director of temporary accommodation of refugees in Odessa, Ilya Malakhov Sergeyevich representatives of the Office for Refugees PG HMS Ukraine in Odessa region. Besides government representatives in the meeting participated various organizations and associations. Representatives of NGO 'Committee on Protection of rights and freedoms of citizens 'Shield' and Charity Fund 'Assalam' ' also visited the event on such a global problem – refugees. Each organization has produced a mini-presentation to tell or show clearly the nature of their activities. All races attended the event had the opportunity to learn about the work of Polish colleagues, share their experiences and exchange views on the above issue. steroids to buy usa",

			},
			{
				title: "Iftar in Odessa",
				date:"13 December 2012",
				text: "Regional public organization “Al Masar” and Islamic Cultural Center in Odessa in headed by Sheikh Imad Abu Alrub organized the dinner or how it’s also called Iftar which in Arabic means the breaking of the fast, the evening meal during the holy month of Ramadan. In this event took part a lot of people among whom were representatives and leaders of various national and cultural societies, Muslim religious leaders of Odessa and even a Sheikh from Egypt. As an invited guest was present the head of the Internal Policy Department of Information and Public Relations of the Odessa City Council Bayzhanov Albert Ivanovich. Opening remarks said Sheikh Imad Abu Alrub, welcomed everyone, highlighted the activities of the Committee on protection of rights and freedoms of citizens “Shield” and Charity Fund “Assalam”. Organizers also prepared video report on the activities of the regional public organization 'Al-Masar' and the Islamic Cultural Center in Odessa. This video shows in detail the robot to these organizations As the last rays of the hid everyone read a pray Al-Maghrib. And then on the tradition they start to brake one’s fast with date on palms and water. Because in the words of the Prophet Muhammad you need to break the fast with date palms and if you do not have them then only with water, because it truly cleans. After the prayers and breaking the fast all the guests all together gathered near the table, where was a lot of different dishes of Arabic national cuisine. Each guest by himself picked the food he wanted. And after all Iftar passed in very hospitable and friendly atmosphere.",

			}
		];
	




})();

